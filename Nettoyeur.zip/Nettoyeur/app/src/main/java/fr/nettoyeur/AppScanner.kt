package fr.nettoyeur

import android.app.usage.StorageStatsManager
import android.content.Context
import android.content.pm.ApplicationInfo
import android.os.Process
import android.os.storage.StorageManager

data class AppEntry(
    val pkg: String,
    val label: String,
    val system: Boolean,
    val enabled: Boolean,
    val hasLauncher: Boolean,
    val cacheBytes: Long,
    val totalBytes: Long,
)

object AppScanner {

    /** Liste les applis installées ; withStats = mesurer cache et taille (accès aux données d'utilisation requis). */
    fun load(ctx: Context, withStats: Boolean): List<AppEntry> {
        val pm = ctx.packageManager
        val ssm = ctx.getSystemService(StorageStatsManager::class.java)
        val user = Process.myUserHandle()

        @Suppress("DEPRECATION")
        val installed = pm.getInstalledApplications(0)

        return installed
            .filter { it.packageName != ctx.packageName }
            .map { ai ->
                var cache = 0L
                var total = 0L
                if (withStats) {
                    try {
                        val s = ssm.queryStatsForPackage(StorageManager.UUID_DEFAULT, ai.packageName, user)
                        cache = s.cacheBytes
                        total = s.appBytes + s.dataBytes
                    } catch (e: Exception) {
                        // appli inaccessible : on l'affiche sans taille
                    }
                }
                AppEntry(
                    pkg = ai.packageName,
                    label = pm.getApplicationLabel(ai).toString(),
                    system = (ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0,
                    enabled = ai.enabled,
                    hasLauncher = pm.getLaunchIntentForPackage(ai.packageName) != null,
                    cacheBytes = cache,
                    totalBytes = total,
                )
            }
    }
}
