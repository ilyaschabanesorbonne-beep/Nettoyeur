package fr.nettoyeur

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun CacheScreen(tick: Int) {
    val ctx = LocalContext.current
    val hasUsage = remember(tick) { Permissions.hasUsageAccess(ctx) }
    var apps by remember { mutableStateOf<List<AppEntry>?>(null) }

    // Rechargé à chaque retour dans l'appli : le cache vidé dans les paramètres disparaît de la liste
    LaunchedEffect(tick, hasUsage) {
        if (hasUsage) {
            apps = withContext(Dispatchers.IO) {
                AppScanner.load(ctx, withStats = true)
                    .filter { it.cacheBytes > 0 }
                    .sortedByDescending { it.cacheBytes }
            }
        }
    }

    Column(Modifier.fillMaxSize()) {
        if (!hasUsage) {
            PermissionCard(
                "Pour mesurer le cache de chaque appli, active « Nettoyeur » dans l'accès aux données d'utilisation.",
                "Autoriser"
            ) { Permissions.requestUsageAccess(ctx) }
        } else {
            val list = apps
            Text(
                "Cache des applis : ${formatSize(list?.sumOf { it.cacheBytes } ?: 0L)}",
                Modifier.padding(horizontal = 16.dp),
                style = MaterialTheme.typography.titleMedium,
            )
            Text(
                "Android n'autorise pas une appli à vider le cache des autres. Touche une appli, puis Stockage › Vider le cache.",
                Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Button(
                onClick = { Permissions.openStorageManager(ctx) },
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
            ) { Text("Gestionnaire de stockage d'Android") }

            if (list == null) {
                Box(
                    Modifier
                        .fillMaxWidth()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center,
                ) { CircularProgressIndicator() }
            } else {
                LazyColumn(Modifier.weight(1f)) {
                    items(list, key = { it.pkg }) { app ->
                        ListItem(
                            leadingContent = { AppIcon(app.pkg) },
                            headlineContent = {
                                Text(app.label, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            },
                            supportingContent = {
                                Text(app.pkg, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            },
                            trailingContent = { Text(formatSize(app.cacheBytes)) },
                            modifier = Modifier.clickable { Permissions.openAppDetails(ctx, app.pkg) },
                        )
                    }
                }
            }
        }
    }
}
