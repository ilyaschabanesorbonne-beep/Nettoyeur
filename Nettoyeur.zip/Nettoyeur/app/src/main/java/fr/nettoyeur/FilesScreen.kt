package fr.nettoyeur

import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun FilesScreen(tick: Int) {
    val ctx = LocalContext.current
    val hasAccess = remember(tick) { Permissions.hasAllFilesAccess() }
    var sections by remember { mutableStateOf<List<Section>?>(null) }
    var progress by remember { mutableStateOf<String?>(null) }
    var showConfirm by remember { mutableStateOf(false) }
    val selected = remember { mutableStateMapOf<String, Boolean>() }
    val expanded = remember { mutableStateMapOf<String, Boolean>() }
    val scope = rememberCoroutineScope()

    if (!hasAccess) {
        PermissionCard(
            "Pour analyser ton stockage (gros fichiers, doublons, fichiers temporaires), Nettoyeur a besoin de l'accès à tous les fichiers.",
            "Autoriser l'accès"
        ) { Permissions.requestAllFilesAccess(ctx) }
        return
    }

    val selectedItems = sections.orEmpty()
        .flatMap { it.items }
        .filter { selected[it.path] == true }
        .distinctBy { it.path }
    val selectedSize = selectedItems.sumOf { it.size }

    Column(Modifier.fillMaxSize()) {
        Button(
            onClick = {
                scope.launch {
                    progress = "Démarrage de l'analyse…"
                    val result = withContext(Dispatchers.IO) {
                        FileScanner.scan { progress = it }
                    }
                    val secs = FileScanner.toSections(result)
                    selected.clear()
                    secs.forEach { s ->
                        s.items.forEach { if (it.defaultSelected) selected[it.path] = true }
                    }
                    sections = secs
                    progress = null
                }
            },
            enabled = progress == null,
            modifier = Modifier.padding(horizontal = 16.dp),
        ) { Text(if (sections == null) "Analyser le stockage" else "Relancer l'analyse") }

        val p = progress
        if (p != null) {
            LinearProgressIndicator(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            )
            Text(
                p,
                Modifier.padding(horizontal = 16.dp),
                style = MaterialTheme.typography.bodySmall,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }

        val secs = sections
        if (secs != null && p == null) {
            val nonEmpty = secs.filter { it.items.isNotEmpty() }
            if (nonEmpty.isEmpty()) {
                Text("Rien à nettoyer, ton stockage est propre !", Modifier.padding(16.dp))
            }
            LazyColumn(Modifier.weight(1f)) {
                nonEmpty.forEach { s ->
                    item(key = "h:${s.key}") {
                        SectionHeader(
                            section = s,
                            expanded = expanded[s.key] == true,
                            allSelected = s.items.all { selected[it.path] == true },
                            onToggleExpand = { expanded[s.key] = expanded[s.key] != true },
                            onToggleAll = { check -> s.items.forEach { selected[it.path] = check } },
                        )
                    }
                    if (expanded[s.key] == true) {
                        items(s.items, key = { "${s.key}:${it.path}" }) { item ->
                            ItemRow(item, selected[item.path] == true) { selected[item.path] = it }
                        }
                    }
                }
            }
            Button(
                onClick = { showConfirm = true },
                enabled = selectedItems.isNotEmpty(),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
            ) { Text("Supprimer ${selectedItems.size} élément(s) · ${formatSize(selectedSize)}") }
        }
    }

    if (showConfirm) {
        // Groupes de doublons dont TOUTES les copies sont cochées
        val dupSection = sections.orEmpty().firstOrNull { it.key == "dup" }
        val riskyGroups = dupSection?.items.orEmpty()
            .groupBy { it.group }
            .count { (_, group) -> group.all { selected[it.path] == true } }

        AlertDialog(
            onDismissRequest = { showConfirm = false },
            title = { Text("Confirmer la suppression") },
            text = {
                Text(
                    buildString {
                        append("${selectedItems.size} élément(s), soit ${formatSize(selectedSize)}, vont être supprimés définitivement.")
                        if (riskyGroups > 0) {
                            append("\n\nAttention : pour $riskyGroups groupe(s) de doublons, toutes les copies sont cochées. Le fichier disparaîtra complètement.")
                        }
                    }
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    showConfirm = false
                    val toDelete = selectedItems
                    scope.launch {
                        val (freed, gone) = withContext(Dispatchers.IO) { FileScanner.delete(ctx, toDelete) }
                        sections = sections?.map { s -> s.copy(items = s.items.filter { it.path !in gone }) }
                        gone.forEach { selected.remove(it) }
                        Toast.makeText(
                            ctx,
                            "${gone.size} élément(s) supprimé(s), ${formatSize(freed)} libérés",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                }) { Text("Supprimer") }
            },
            dismissButton = {
                TextButton(onClick = { showConfirm = false }) { Text("Annuler") }
            },
        )
    }
}

@Composable
private fun SectionHeader(
    section: Section,
    expanded: Boolean,
    allSelected: Boolean,
    onToggleExpand: () -> Unit,
    onToggleAll: (Boolean) -> Unit,
) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onToggleExpand)
            .padding(horizontal = 8.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Checkbox(checked = allSelected, onCheckedChange = onToggleAll)
        Column(Modifier.weight(1f)) {
            Text(section.title, style = MaterialTheme.typography.titleMedium)
            Text(
                "${section.items.size} élément(s) · ${formatSize(section.items.sumOf { it.size })}",
                style = MaterialTheme.typography.bodySmall,
            )
            if (section.hint.isNotEmpty()) {
                Text(
                    section.hint,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        Icon(
            if (expanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
            contentDescription = if (expanded) "Replier" else "Déplier",
        )
    }
    HorizontalDivider()
}

@Composable
private fun ItemRow(item: CleanItem, checked: Boolean, onChecked: (Boolean) -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable { onChecked(!checked) }
            .padding(start = 24.dp, end = 16.dp, top = 2.dp, bottom = 2.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Checkbox(checked = checked, onCheckedChange = onChecked)
        Column(Modifier.weight(1f)) {
            Text(
                item.title,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                style = MaterialTheme.typography.bodyMedium,
            )
            Text(
                item.subtitle,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        Text(formatSize(item.size), style = MaterialTheme.typography.labelMedium)
    }
}
