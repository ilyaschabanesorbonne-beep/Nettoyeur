package fr.nettoyeur

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppsScreen(tick: Int) {
    val ctx = LocalContext.current
    val hasUsage = remember(tick) { Permissions.hasUsageAccess(ctx) }
    var apps by remember { mutableStateOf<List<AppEntry>?>(null) }
    var showSystem by rememberSaveable { mutableStateOf(false) }

    // Rechargé au retour d'une désinstallation ou des paramètres
    LaunchedEffect(tick, hasUsage) {
        apps = withContext(Dispatchers.IO) { AppScanner.load(ctx, hasUsage) }
    }

    val list = apps
    if (list == null) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        return
    }

    val userApps = list.filter { !it.system }
    // Applis préinstallées visibles dans le tiroir d'applis (le vrai « bloatware ») + celles déjà désactivées
    val systemApps = list.filter { it.system && (it.hasLauncher || !it.enabled) }
    val comparator: Comparator<AppEntry> =
        if (hasUsage) compareByDescending<AppEntry> { it.totalBytes } else compareBy<AppEntry> { it.label.lowercase() }
    val shown = (if (showSystem) systemApps else userApps).sortedWith(comparator)

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            FilterChip(
                selected = !showSystem,
                onClick = { showSystem = false },
                label = { Text("Mes applis (${userApps.size})") },
            )
            FilterChip(
                selected = showSystem,
                onClick = { showSystem = true },
                label = { Text("Préinstallées (${systemApps.size})") },
            )
        }
        Text(
            if (showSystem)
                "Les applis préinstallées ne se désinstallent pas depuis le téléphone. Touche « Désactiver » puis le bouton Désactiver des paramètres : l'appli disparaît et ne tourne plus. Si le bouton est grisé, elle est indispensable au système."
            else
                "Touche « Désinstaller » pour supprimer une appli dont tu ne te sers plus.",
            Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        if (!hasUsage) {
            TextButton(
                onClick = { Permissions.requestUsageAccess(ctx) },
                modifier = Modifier.padding(horizontal = 8.dp),
            ) { Text("Afficher la taille de chaque appli") }
        }

        LazyColumn(Modifier.weight(1f)) {
            items(shown, key = { it.pkg }) { app ->
                ListItem(
                    leadingContent = { AppIcon(app.pkg) },
                    headlineContent = {
                        Text(app.label, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    },
                    supportingContent = {
                        Text(
                            buildString {
                                if (hasUsage) append(formatSize(app.totalBytes)).append(" · ")
                                append(app.pkg)
                                if (!app.enabled) append(" · désactivée")
                            },
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    },
                    trailingContent = {
                        if (app.system) {
                            TextButton(onClick = { Permissions.openAppDetails(ctx, app.pkg) }) {
                                Text(if (app.enabled) "Désactiver" else "Gérer")
                            }
                        } else {
                            TextButton(onClick = { Permissions.uninstall(ctx, app.pkg) }) {
                                Text("Désinstaller")
                            }
                        }
                    },
                )
            }
        }
    }
}
