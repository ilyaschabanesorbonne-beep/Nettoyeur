package fr.nettoyeur

import android.content.Context
import android.media.MediaScannerConnection
import android.os.Environment
import java.io.File
import java.security.MessageDigest

data class FoundFile(val file: File, val size: Long)

data class ScanResult(
    val bigFiles: List<FoundFile>,
    val duplicates: List<List<FoundFile>>,
    val apks: List<FoundFile>,
    val tempFiles: List<FoundFile>,
    val emptyDirs: List<File>,
)

data class CleanItem(
    val path: String,
    val title: String,
    val subtitle: String,
    val size: Long,
    val defaultSelected: Boolean,
    val group: Int? = null, // numéro de groupe pour les doublons
)

data class Section(val key: String, val title: String, val hint: String, val items: List<CleanItem>)

object FileScanner {

    private const val BIG_FILE = 50L * 1024 * 1024
    private const val PARTIAL = 64 * 1024

    private val TEMP_EXT = setOf("tmp", "temp", "log", "bak", "old", "part", "crdownload", "chk")
    private val TEMP_DIRS = setOf(".thumbnails", ".cache", ".tmp", "LOST.DIR")
    private val SKIP = setOf("Android/data", "Android/obb") // inaccessibles depuis Android 11

    fun scan(onProgress: (String) -> Unit): ScanResult {
        val root = Environment.getExternalStorageDirectory()
        val rootPath = root.absolutePath
        val all = ArrayList<FoundFile>()
        val temp = ArrayList<FoundFile>()
        val empty = ArrayList<File>()
        var lastReport = 0L

        // Renvoie true si le dossier est vide (ou ne contient que des dossiers vides)
        fun walk(dir: File, inTempDir: Boolean, depth: Int): Boolean {
            val now = System.currentTimeMillis()
            if (now - lastReport > 200) {
                lastReport = now
                onProgress(dir.absolutePath.removePrefix(rootPath).ifEmpty { "/" })
            }
            val children = dir.listFiles() ?: return false
            var isEmpty = true
            val emptyChildren = ArrayList<File>()
            for (child in children) {
                val rel = child.absolutePath.removePrefix("$rootPath/")
                if (rel in SKIP) {
                    isEmpty = false
                    continue
                }
                if (child.isDirectory) {
                    if (depth > 40) {
                        isEmpty = false
                        continue
                    }
                    val childTemp = inTempDir || child.name in TEMP_DIRS
                    if (walk(child, childTemp, depth + 1)) emptyChildren += child else isEmpty = false
                } else {
                    isEmpty = false
                    val f = FoundFile(child, child.length())
                    all += f
                    if (inTempDir || child.extension.lowercase() in TEMP_EXT) temp += f
                }
            }
            // On ne signale pas les dossiers standards à la racine (Music, Movies…)
            if (!isEmpty && dir.absolutePath != rootPath) empty += emptyChildren
            return isEmpty
        }

        walk(root, false, 0)
        onProgress("Recherche des doublons…")
        val duplicates = findDuplicates(all, onProgress)

        return ScanResult(
            bigFiles = all.filter { it.size >= BIG_FILE }.sortedByDescending { it.size },
            duplicates = duplicates,
            apks = all.filter { it.file.extension.equals("apk", ignoreCase = true) }
                .sortedByDescending { it.size },
            tempFiles = temp.sortedByDescending { it.size },
            emptyDirs = empty.filter { !it.absolutePath.startsWith("$rootPath/Android") }
                .sortedBy { it.absolutePath },
        )
    }

    private fun findDuplicates(all: List<FoundFile>, onProgress: (String) -> Unit): List<List<FoundFile>> {
        // 1) même taille  2) même début de fichier  3) même empreinte complète
        val bySize = all.filter { it.size >= 4096 }
            .groupBy { it.size }.values
            .filter { it.size > 1 }
        val result = ArrayList<List<FoundFile>>()
        for ((i, sameSize) in bySize.withIndex()) {
            if (i % 20 == 0) onProgress("Comparaison des fichiers… ${i * 100 / bySize.size} %")
            val byPartial = sameSize.groupBy { hash(it.file, PARTIAL.toLong()) }
                .filterKeys { it != null }.values
                .filter { it.size > 1 }
            for (candidates in byPartial) {
                val groups = if (candidates.first().size <= PARTIAL) listOf(candidates)
                else candidates.groupBy { hash(it.file) }
                    .filterKeys { it != null }.values
                    .filter { it.size > 1 }
                groups.forEach { g -> result += g.sortedBy { it.file.lastModified() } }
            }
        }
        return result.sortedByDescending { it.first().size * (it.size - 1) }
    }

    private fun hash(file: File, limit: Long = Long.MAX_VALUE): String? = try {
        val md = MessageDigest.getInstance("MD5")
        file.inputStream().buffered().use { input ->
            val buf = ByteArray(64 * 1024)
            var total = 0L
            while (total < limit) {
                val toRead = minOf(buf.size.toLong(), limit - total).toInt()
                val n = input.read(buf, 0, toRead)
                if (n <= 0) break
                md.update(buf, 0, n)
                total += n
            }
        }
        md.digest().joinToString("") { "%02x".format(it) }
    } catch (e: Exception) {
        null
    }

    fun toSections(r: ScanResult): List<Section> {
        val root = Environment.getExternalStorageDirectory().absolutePath
        fun where(f: File): String = f.parent?.removePrefix(root)?.ifEmpty { "/" } ?: ""
        fun item(f: FoundFile, selected: Boolean) =
            CleanItem(f.file.absolutePath, f.file.name, where(f.file), f.size, selected)

        val dupItems = ArrayList<CleanItem>()
        r.duplicates.forEachIndexed { gi, group ->
            group.forEachIndexed { idx, f ->
                dupItems += CleanItem(
                    path = f.file.absolutePath,
                    title = f.file.name,
                    subtitle = (if (idx == 0) "Original conservé · " else "Copie · ") + where(f.file),
                    size = f.size,
                    defaultSelected = idx > 0,
                    group = gi,
                )
            }
        }

        return listOf(
            Section(
                "temp", "Fichiers temporaires",
                "Miniatures, journaux, fichiers partiels : suppression sans risque.",
                r.tempFiles.map { item(it, true) }
            ),
            Section(
                "empty", "Dossiers vides", "",
                r.emptyDirs.map { CleanItem(it.absolutePath, it.name, where(it), 0, true) }
            ),
            Section(
                "dup", "Doublons",
                "La copie la plus ancienne de chaque groupe est conservée.",
                dupItems
            ),
            Section(
                "apk", "Fichiers d'installation (APK)",
                "Inutiles une fois l'appli installée.",
                r.apks.map { item(it, false) }
            ),
            Section(
                "big", "Gros fichiers (50 Mo et plus)",
                "Vérifie avant de supprimer : vidéos, sauvegardes…",
                r.bigFiles.map { item(it, false) }
            ),
        )
    }

    /** Supprime les éléments ; renvoie l'espace libéré et les chemins effectivement supprimés. */
    fun delete(ctx: Context, items: List<CleanItem>): Pair<Long, Set<String>> {
        var freed = 0L
        val gone = HashSet<String>()
        for (item in items) {
            val f = File(item.path)
            val ok = if (f.isDirectory) f.deleteRecursively() else f.delete()
            if (ok || !f.exists()) {
                freed += item.size
                gone += item.path
            }
        }
        // Met à jour la galerie et les applis de médias
        if (gone.isNotEmpty()) MediaScannerConnection.scanFile(ctx, gone.toTypedArray(), null, null)
        return freed to gone
    }
}
